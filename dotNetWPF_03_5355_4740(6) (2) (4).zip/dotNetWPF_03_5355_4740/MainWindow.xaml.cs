﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dotNetWPF_03_1288_8805
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PrinterUserControl CourentPrinter;
        Queue<PrinterUserControl> queue;
        /// <summary>
        /// initialize the Main Window
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            queue = new Queue<PrinterUserControl>();
            foreach (PrinterUserControl item in printerGrid.Children.OfType<PrinterUserControl>())
            {
                item.PageMissing += page_error_handler;
                item.InkEmpty += ink_error_handler;
                queue.Enqueue(item);
            }
            CourentPrinter = queue.Dequeue();
        }

        /// <summary>
        /// repairing the page errors
        /// </summary>
        /// <param name="sender">the object that called this function</param>
        /// <param name="e"></param>
        private void page_error_handler(object sender, PrinterEventArgs e)
        {
            MessageBox.Show("At: " + e.when + "\nMessage from printer: " + e.Message, e.NAME + " Pages Missing!!!", MessageBoxButton.OK, MessageBoxImage.Error);
            if (e.iscritic && sender == CourentPrinter)
            {
                queue.Enqueue(CourentPrinter);
                CourentPrinter = queue.Dequeue();
            }
            (sender as PrinterUserControl).add_pages();
        }
        /// <summary>
        /// repairing the ink errors
        /// </summary>
        /// <param name="sender">the object that called this function</param>
        /// <param name="e"></param>
        private void ink_error_handler(object sender, PrinterEventArgs e)
        {
            if (e.iscritic)
            {
                MessageBox.Show("At: " + e.when + "\nMessage from printer: " + e.Message, e.NAME + " Ink Missing!!!", MessageBoxButton.OK, MessageBoxImage.Error);
                if (sender == CourentPrinter)
                {
                    queue.Enqueue(CourentPrinter);
                    CourentPrinter = queue.Dequeue();
                }
                (sender as PrinterUserControl).add_ink();
            }
            else
                MessageBox.Show("At: " + e.when + "\nMessage from printer: " + e.Message, e.NAME + " Ink Missing!!!", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        /// <summary>
        /// prints when someone presses the button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void printButton_Click(object sender, RoutedEventArgs e)
        {
            CourentPrinter.print();
        }
    }
}
