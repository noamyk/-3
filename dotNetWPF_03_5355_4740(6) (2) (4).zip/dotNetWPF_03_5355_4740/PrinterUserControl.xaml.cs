﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dotNetWPF_03_1288_8805
{
    /// <summary>
    /// Interaction logic for PrinterUserControl.xaml
    /// </summary>
    public partial class PrinterUserControl : UserControl
    {
        private EventHandler<PrinterEventArgs> page_missing;
        private EventHandler<PrinterEventArgs> ink_empty;
        private static Random rand = new Random();
        private static uint i = 0;
        public const double MAX_INK = 100;
        public const double MIN_ADD_INK = 17;
        public const double MAX_ADD_INK = 93;
        public const int MAX_PAGES = 400;
        public const int MIN_ADD_PAGES = 51;
        public const int MAX_ADD_PAGES = 391;

        /// <summary>
        /// add and remove functions to and from the event PageMissing
        /// </summary>
        public event EventHandler<PrinterEventArgs> PageMissing
        {
            add
            {
                page_missing += value;
            }
            remove
            {
                page_missing -= value;
            }
        }
        /// <summary>
        /// add and remove functions to and from the event InkEmpty
        /// </summary>
        public event EventHandler<PrinterEventArgs> InkEmpty
        {
            add
            {
                ink_empty += value;
            }
            remove
            {
                ink_empty -= value;
            }
        }
        /// <summary>
        /// get and set the PrinterName
        /// </summary>
        public string PrinterName
        {
            get
            {
                return printerNameLabel.Content as string;
            }
            set
            {
                printerNameLabel.Content = value;
            }
        }
        /// <summary>
        /// get and set the InkCount and handles the problems that may occur
        /// </summary>
        public double InkCount
        {
            get
            {
                return ((double)(int)(inkCountProgressBar.Value * 10)) / 10;
            }
            set
            {
                if (value < 0)
                    inkCountProgressBar.Value = 0;
                else
                    inkCountProgressBar.Value = value;

                inkCountProgressBar.ToolTip = InkCount.ToString() + '%';
                if (value <= 0 && ink_empty != null)
                    ink_empty(this, new PrinterEventArgs(true, "Your ink is over", PrinterName));
                else if (value < 1)
                    ink_empty(this, new PrinterEventArgs(true, "Your ink is only " + InkCount + "%", PrinterName));
                else if (InkCount <= 15 && ink_empty != null)
                    ink_empty(this, new PrinterEventArgs(false, "Your ink is only " + InkCount + "%", PrinterName));
            }
        }
        /// <summary>
        /// get and set the PageMissing and handles the problems that may occur
        /// </summary>
        public int PageCount
        {
            get
            {
                return (int)pageCountSlider.Value;
            }
            set
            {
                if (value < 0)
                {
                    pageCountSlider.Value = 0;
                    if (page_missing != null)
                        page_missing(this, new PrinterEventArgs(true, ("Missing " + ((-1) * value) + " pages"), PrinterName));
                }
                else
                    pageCountSlider.Value = value;
            }
        }
        /// <summary>
        /// initialize the PrinterUserControl and the tooltips of the inkCountProgressBar and the pageCountSlider
        /// </summary>
        public PrinterUserControl()
        {
            i++;
            InitializeComponent();
            inkCountProgressBar.Maximum = MAX_INK;
            inkCountProgressBar.ToolTip = new ToolTip();
            inkCountProgressBar.ToolTip = InkCount.ToString() + '%';

            pageCountSlider.Maximum = MAX_PAGES;
            pageCountSlider.ToolTip = new ToolTip();
            pageCountSlider.ToolTip = PageCount;

            PrinterName = "Printer " + i;
        }

        /// <summary>
        /// getting the printerNameLabel smaller when the mouse leaves it
        /// </summary>
        /// <param name="sender">the object that called this function</param>
        /// <param name="e"></param>
        private void PrinterNameLabel_MouseLeave(object sender, MouseEventArgs e)
        {
            printerNameLabel.FontSize = 16;
        }
        /// <summary>
        /// getting the printerNameLabel bigger when the mouse enters it
        /// </summary>
        /// <param name="sender">the object that called this function</param>
        /// <param name="e"></param>
        private void PrinterNameLabel_MouseEnter(object sender, MouseEventArgs e)
        {
            printerNameLabel.FontSize = 40;
        }

        /// <summary>
        /// returns a random double between MIN and MAX
        /// </summary>
        /// <param name="MIN">the minimum number for the random</param>
        /// <param name="MAX">the maximum number for the random</param>
        /// <returns></returns>
        private double doublerand(double MIN = 0, double MAX = 0)
        {
            return rand.Next((int)MIN, (int)MAX) + ((double)rand.Next(99999999) / 100000000);
        }

        /// <summary>
        /// prints whith a random amount of ink and pages
        /// </summary>
        public void print()
        {
            InkCount -= doublerand(0, MAX_INK / 15);
            PageCount -= rand.Next(MAX_PAGES / 10);

        }
        /// <summary>
        /// adds a random amount of ink
        /// </summary>
        public void add_ink()
        {
            inkLabel.Foreground = Brushes.Black;
            InkCount += doublerand(MIN_ADD_INK, MAX_ADD_INK - inkCountProgressBar.Value);
        }
        /// <summary>
        /// adds a random amount of pages
        /// </summary>
        public void add_pages()
        {

            PageCount += rand.Next(MIN_ADD_PAGES, MAX_ADD_PAGES - PageCount);
        }

        /// <summary>
        /// paints the pageLabel in the color that it should be when the pageCountSlider value changes
        /// </summary>
        /// <param name="sender">the object that called this function</param>
        /// <param name="e"></param>
        private void pageCountSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            pageCountSlider.ToolTip = PageCount;
            if (pageCountSlider.Value <= 0)
                pageLabel.Foreground = Brushes.Red;
            else
                pageLabel.Foreground = Brushes.Black;
        }

        /// <summary>
        /// paints the inkLabel in the color that it should be when the pageCountSlider value changes
        /// </summary>
        /// <param name="sender">the object that called this function</param>
        /// <param name="e"></param>
        private void inkCountProgressBar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (inkCountProgressBar.Value <= 15 && inkCountProgressBar.Value >= 10)
            {
                inkLabel.Foreground = Brushes.Yellow;
            }
            else if (inkCountProgressBar.Value <= 10 && inkCountProgressBar.Value >= 1)
            {
                inkLabel.Foreground = Brushes.Orange;
            }
            else if (inkCountProgressBar.Value > 0 && inkCountProgressBar.Value < 1)
            {
                inkLabel.Foreground = Brushes.Red;
            }
            else if (inkCountProgressBar.Value <= 0)
            {
                inkLabel.Foreground = Brushes.Red;
            }
        }
    }

    public class PrinterEventArgs : EventArgs
    {
        private bool iscritical;
        private DateTime datetime_of_the_error;
        private string Error_warrning_Message;
        private string printer_name;

        /// <summary>
        /// returns true if the error is critic
        /// </summary>
        public bool iscritic
        {
            get
            {
                return iscritical;
            }
        }
        /// <summary>
        /// returns the time that the error occured
        /// </summary>
        public DateTime when
        {
            get
            {
                return datetime_of_the_error;
            }
        }
        /// <summary>
        /// returns the message of the error
        /// </summary>
        public string Message
        {
            get
            {
                return Error_warrning_Message;
            }
        }
        /// <summary>
        /// returns the name of the printer that the error happend in it
        /// </summary>
        public string NAME
        {
            get
            {
                return printer_name;
            }
        }

        /// <summary>
        /// creates a PrinterEventArgs form and initialize the parameters
        /// </summary>
        /// <param name="iscriti">is the error critic</param>
        /// <param name="ErrorWarrningMessage">the error message</param>
        /// <param name="NAME">the name of the printer that the error occured in it</param>
        public PrinterEventArgs(bool iscriti, string ErrorWarrningMessage, string NAME)
        {
            datetime_of_the_error = DateTime.Now;
            iscritical = iscriti;
            Error_warrning_Message = ErrorWarrningMessage;
            printer_name = NAME;
        }

    }
}
